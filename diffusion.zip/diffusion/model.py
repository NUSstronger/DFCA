# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# GLIDE: https://github.com/openai/glide-text2im
# MAE: https://github.com/facebookresearch/mae/blob/main/models_mae.py
# --------------------------------------------------------

import torch
import torch.nn as nn
import numpy as np
import math
from timm.models.vision_transformer import PatchEmbed, Attention, Mlp


class BondDecoupledMLP(nn.Module):
    """
    Ablation module A: use_fusion controls the fusion layer.
    - use_fusion=True: xy and z streams interact through a fusion layer (enhanced version)
    - use_fusion=False: xy and z streams are concatenated directly after separate processing (baseline for ablation)
    """
    def __init__(self, in_features, hidden_features=None, act_layer=nn.GELU, drop=0., use_fusion=True):
        super().__init__()
        self.half_in = in_features // 2
        self.use_fusion = use_fusion

        self.mlp_xy = Mlp(in_features=self.half_in, hidden_features=hidden_features, act_layer=act_layer, drop=drop)
        self.mlp_z = Mlp(in_features=self.half_in, hidden_features=hidden_features, act_layer=act_layer, drop=drop)

        # Fusion layer: enables xy and z features to interact after separate processing (controlled by use_fusion).
        if self.use_fusion:
            self.fusion = nn.Sequential(
                nn.Linear(in_features, in_features),
                act_layer(),
                nn.Linear(in_features, in_features),
                nn.Dropout(drop)
            )

    def forward(self, x):
        x_xy, x_z = torch.chunk(x, 2, dim=-1)

        out_xy = self.mlp_xy(x_xy)
        out_z = self.mlp_z(x_z)

        out = torch.cat([out_xy, out_z], dim=-1)

        # Ablation switch: whether to apply the fusion layer.
        if self.use_fusion:
            out = self.fusion(out)
        return out


class RelativePositionBias(nn.Module):
    """Relative-position bias for the XY plane, enhancing in-plane periodicity awareness."""

    def __init__(self, num_heads):
        super().__init__()
        self.num_heads = num_heads
        # Maps distance to per-head bias terms.
        self.distance_embed = nn.Sequential(
            nn.Linear(1, 32),
            nn.GELU(),
            nn.Linear(32, num_heads)
        )

    def forward(self, xy_coords, lattice_xy_basis=None):
        """
        Args:
            xy_coords: [B, N, 2] fractional xy coordinates
            lattice_xy_basis: [B, 2, 2] lattice xy basis vectors
        Returns:
            bias: [B, num_heads, N, N]
        """
        if xy_coords is None:
            return None
        B, N, _ = xy_coords.shape
        atom_tokens = max(N - 3, 0)
        bias = torch.zeros(B, N, N, self.num_heads, device=xy_coords.device, dtype=xy_coords.dtype)
        if atom_tokens == 0:
            return bias.permute(0, 3, 1, 2)
        atom_xy = xy_coords[:, :atom_tokens, :]
        diff_frac = atom_xy.unsqueeze(2) - atom_xy.unsqueeze(1)
        diff_frac = diff_frac - torch.round(diff_frac)
        if lattice_xy_basis is not None:
            diff_cart = torch.einsum('bijd,bdk->bijk', diff_frac, lattice_xy_basis)
        else:
            diff_cart = diff_frac
        distances = torch.norm(diff_cart, dim=-1, keepdim=True)
        atom_bias = self.distance_embed(distances)
        bias[:, :atom_tokens, :atom_tokens, :] = atom_bias
        return bias.permute(0, 3, 1, 2)


class DualStream_DFCA_Attention(nn.Module):
    """
    Ablation module B: cross_attn_mode controls the cross-attention mode.

    Three modes for ablation:
    - 'bidirectional': bidirectional cross-attention (enhanced; z_from_xy is the dominant direction)
    - 'xy_to_z': unidirectional (XY queries Z; baseline)
    - 'none': no cross-attention (pure dual-stream self-attention)
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.,
                 z_from_xy_init=0.782159, xy_from_z_init=0.1, cross_attn_mode='bidirectional'):
        super().__init__()
        self.half_dim = dim // 2
        self.num_heads_xy = num_heads // 2
        self.num_heads_z = num_heads // 2
        head_dim = (dim // 2) // (num_heads // 2)
        self.scale = head_dim ** -0.5

        # XY-Stream: QKV
        self.qkv_xy = nn.Linear(self.half_dim, self.half_dim * 3, bias=qkv_bias)

        # Z-Stream: QKV
        self.qkv_z = nn.Linear(self.half_dim, self.half_dim * 3, bias=qkv_bias)

        # Relative position bias (XY-Stream only).
        self.rel_pos_bias = RelativePositionBias(self.num_heads_xy)

        # Ablation switch: cross-attention mode.
        self.cross_attn_mode = cross_attn_mode

        # Bidirectional cross-attention gates.
        if cross_attn_mode == 'bidirectional':
            # z_from_xy: Z attends to XY (layer thickness determined by in-plane arrangement) — dominant direction.
            self.gate_z_from_xy = nn.Parameter(torch.tensor(z_from_xy_init))
            # xy_from_z: XY attends to Z — auxiliary direction.
            self.gate_xy_from_z = nn.Parameter(torch.tensor(xy_from_z_init))
        elif cross_attn_mode == 'xy_to_z':
            # Unidirectional baseline: XY queries Z.
            self.cross_attn_scale = nn.Parameter(torch.tensor(0.5))
        # cross_attn_mode == 'none': no cross-attention.

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x, attn_mask=None, xy_coords=None, lattice_xy_basis=None):
        """
        Args:
            x: [B, N, C] input features
            attn_mask: attention mask
            xy_coords: [B, N, 2] fractional xy coordinates for relative position bias
            lattice_xy_basis: [B, 2, 2] lattice xy basis vectors
        """
        B, N, C = x.shape
        x_xy, x_z = torch.chunk(x, 2, dim=-1)

        # === XY-Stream self-attention + relative position bias ===
        qkv_xy = self.qkv_xy(x_xy).reshape(B, N, 3, self.num_heads_xy, -1).permute(2, 0, 3, 1, 4)
        q_xy, k_xy, v_xy = qkv_xy[0], qkv_xy[1], qkv_xy[2]

        attn_xy = (q_xy @ k_xy.transpose(-2, -1)) * self.scale

        # Apply relative position bias.
        rel_bias = self.rel_pos_bias(xy_coords, lattice_xy_basis=lattice_xy_basis)
        if rel_bias is not None:
            attn_xy = attn_xy + rel_bias

        if attn_mask is not None:
            attn_xy = attn_xy + attn_mask
        attn_xy = attn_xy.softmax(dim=-1)
        attn_xy = self.attn_drop(attn_xy)
        out_xy = (attn_xy @ v_xy).transpose(1, 2).reshape(B, N, self.half_dim)

        # === Z-Stream self-attention ===
        qkv_z = self.qkv_z(x_z).reshape(B, N, 3, self.num_heads_z, -1).permute(2, 0, 3, 1, 4)
        q_z, k_z, v_z = qkv_z[0], qkv_z[1], qkv_z[2]

        attn_z = (q_z @ k_z.transpose(-2, -1)) * self.scale
        if attn_mask is not None:
            attn_z = attn_z + attn_mask
        attn_z = attn_z.softmax(dim=-1)
        attn_z = self.attn_drop(attn_z)
        out_z = (attn_z @ v_z).transpose(1, 2).reshape(B, N, self.half_dim)

        # === Cross-attention (ablation switch) ===
        if self.cross_attn_mode == 'bidirectional':
            # Bidirectional cross-attention (enhanced).
            # 1. z_from_xy: Z queries XY (dominant: in-plane arrangement determines inter-layer thickness).
            attn_z_from_xy = (q_z @ k_xy.transpose(-2, -1)) * self.scale
            if attn_mask is not None:
                attn_z_from_xy = attn_z_from_xy + attn_mask
            attn_z_from_xy = attn_z_from_xy.softmax(dim=-1)
            attn_z_from_xy = self.attn_drop(attn_z_from_xy)
            cross_z_from_xy = (attn_z_from_xy @ v_xy).transpose(1, 2).reshape(B, N, self.half_dim)

            # 2. xy_from_z: XY queries Z (auxiliary direction).
            attn_xy_from_z = (q_xy @ k_z.transpose(-2, -1)) * self.scale
            if attn_mask is not None:
                attn_xy_from_z = attn_xy_from_z + attn_mask
            attn_xy_from_z = attn_xy_from_z.softmax(dim=-1)
            attn_xy_from_z = self.attn_drop(attn_xy_from_z)
            cross_xy_from_z = (attn_xy_from_z @ v_z).transpose(1, 2).reshape(B, N, self.half_dim)

            out_z = out_z + self.gate_z_from_xy * cross_z_from_xy
            out_xy = out_xy + self.gate_xy_from_z * cross_xy_from_z

        elif self.cross_attn_mode == 'xy_to_z':
            # Unidirectional baseline: XY queries Z.
            attn_cross = (q_xy @ k_z.transpose(-2, -1)) * self.scale
            if attn_mask is not None:
                attn_cross = attn_cross + attn_mask
            attn_cross = attn_cross.softmax(dim=-1)
            attn_cross = self.attn_drop(attn_cross)
            cross_out = (attn_cross @ v_z).transpose(1, 2).reshape(B, N, self.half_dim)
            out_xy = out_xy + self.cross_attn_scale * cross_out
        # cross_attn_mode == 'none': no cross-attention.

        # Merge streams.
        out = torch.cat([out_xy, out_z], dim=-1)
        out = self.proj(out)
        out = self.proj_drop(out)
        return out

def modulate(x, shift, scale):
    return x * (1 + scale.unsqueeze(1)) + shift.unsqueeze(1)


#################################################################################
#               Embedding Layers for Timesteps and Class Labels                 #
#################################################################################

class TimestepEmbedder(nn.Module):
    """
    Embeds scalar timesteps into vector representations.
    """
    def __init__(self, hidden_size, frequency_embedding_size=256):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(frequency_embedding_size, hidden_size, bias=True),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size, bias=True),
        )
        self.frequency_embedding_size = frequency_embedding_size

    @staticmethod
    def timestep_embedding(t, dim, max_period=10000):
        """
        Create sinusoidal timestep embeddings.
        :param t: a 1-D Tensor of N indices, one per batch element.
                          These may be fractional.
        :param dim: the dimension of the output.
        :param max_period: controls the minimum frequency of the embeddings.
        :return: an (N, D) Tensor of positional embeddings.
        """
        # https://github.com/openai/glide-text2im/blob/main/glide_text2im/nn.py
        half = dim // 2
        freqs = torch.exp(
            -math.log(max_period) * torch.arange(start=0, end=half, dtype=torch.float32) / half
        ).to(device=t.device)
        args = t[:, None].float() * freqs[None]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if dim % 2:
            embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)
        return embedding

    def forward(self, t):
        t_freq = self.timestep_embedding(t, self.frequency_embedding_size)
        t_emb = self.mlp(t_freq)
        return t_emb


class LabelEmbedder(nn.Module):
    """
    Embeds class labels into vector representations. Also handles label dropout for classifier-free guidance.
    """
    def __init__(self, num_classes, hidden_size, dropout_prob):
        super().__init__()
        use_cfg_embedding = dropout_prob > 0
        self.embedding_table = nn.Embedding(num_classes + use_cfg_embedding, hidden_size)
        self.num_classes = num_classes
        self.dropout_prob = dropout_prob

    def token_drop(self, labels, force_drop_ids=None):
        """
        Drops labels to enable classifier-free guidance.
        """
        if force_drop_ids is None:
            drop_ids = torch.rand(labels.shape[0], device=labels.device) < self.dropout_prob
        else:
            drop_ids = force_drop_ids == 1
        labels = torch.where(drop_ids, self.num_classes, labels)
        return labels

    def forward(self, labels, train, force_drop_ids=None):
        use_dropout = self.dropout_prob > 0
        if (train and use_dropout) or (force_drop_ids is not None):
            labels = self.token_drop(labels, force_drop_ids)
        embeddings = self.embedding_table(labels)
        return embeddings


#################################################################################
#                                 Core DiT Model                                #
#################################################################################

class DiTBlock(nn.Module):
    """
    DiT block with ablation switches:
    - use_fusion: enable MLP fusion layer
    - cross_attn_mode: cross-attention mode ('bidirectional' | 'xy_to_z' | 'none')
    """
    def __init__(self, hidden_size, num_heads, mlp_ratio=4.0,
                 use_fusion=True, cross_attn_mode='bidirectional', **block_kwargs):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)

        # Ablation module B: cross-attention mode.
        self.attn = DualStream_DFCA_Attention(
            hidden_size, num_heads=num_heads, qkv_bias=True,
            cross_attn_mode=cross_attn_mode, **block_kwargs
        )

        self.norm2 = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        mlp_hidden_dim = int(hidden_size * mlp_ratio)
        approx_gelu = lambda: nn.GELU(approximate="tanh")

        # Ablation module A: MLP fusion layer.
        self.mlp = BondDecoupledMLP(
            in_features=hidden_size, hidden_features=mlp_hidden_dim,
            act_layer=approx_gelu, drop=0, use_fusion=use_fusion
        )

        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_size, 6 * hidden_size, bias=True)
        )

    def forward(self, x, c, attn_mask=None, xy_coords=None, lattice_xy_basis=None):
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = self.adaLN_modulation(c).chunk(6, dim=1)

        x = x + gate_msa.unsqueeze(1) * self.attn(modulate(self.norm1(x), shift_msa, scale_msa), attn_mask=attn_mask, xy_coords=xy_coords, lattice_xy_basis=lattice_xy_basis)
        x = x + gate_mlp.unsqueeze(1) * self.mlp(modulate(self.norm2(x), shift_mlp, scale_mlp))
        return x


class FinalLayer(nn.Module):
    """
    The final layer of DiT.
    """
    def __init__(self, hidden_size, patch_size, out_channels):
        super().__init__()
        self.norm_final = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.linear = nn.Linear(hidden_size, patch_size * patch_size * out_channels, bias=True)
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_size, 2 * hidden_size, bias=True)
        )

    def forward(self, x, c):
        shift, scale = self.adaLN_modulation(c).chunk(2, dim=1)
        x = modulate(self.norm_final(x), shift, scale)
        x = self.linear(x)
        return x


class DiT(nn.Module):
    """
    Diffusion model with a Transformer backbone.
    """
    def __init__(
        self,
        input_size=32,
        patch_size=2,
        in_channels=4,
        hidden_size=1152,
        depth=28,
        num_heads=16,
        mlp_ratio=4.0,
        class_dropout_prob=0.1,
        num_classes=1000,
        learn_sigma=True,
    ):
        super().__init__()
        self.learn_sigma = learn_sigma
        self.in_channels = in_channels
        self.out_channels = in_channels * 2 if learn_sigma else in_channels
        self.patch_size = patch_size
        self.num_heads = num_heads

        self.x_embedder = PatchEmbed(input_size, patch_size, in_channels, hidden_size, bias=True)
        self.t_embedder = TimestepEmbedder(hidden_size)
        self.y_embedder = LabelEmbedder(num_classes, hidden_size, class_dropout_prob)
        num_patches = self.x_embedder.num_patches
        # Will use fixed sin-cos embedding:
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, hidden_size), requires_grad=False)

        self.blocks = nn.ModuleList([
            DiTBlock(hidden_size, num_heads, mlp_ratio=mlp_ratio) for _ in range(depth)
        ])
        self.final_layer = FinalLayer(hidden_size, patch_size, self.out_channels)
        self.initialize_weights()

    def initialize_weights(self):
        # Initialize transformer layers:
        def _basic_init(module):
            if isinstance(module, nn.Linear):
                torch.nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
        self.apply(_basic_init)

        # Initialize (and freeze) pos_embed by sin-cos embedding:
        pos_embed = get_2d_sincos_pos_embed(self.pos_embed.shape[-1], int(self.x_embedder.num_patches ** 0.5))
        self.pos_embed.data.copy_(torch.from_numpy(pos_embed).float().unsqueeze(0))

        # Initialize patch_embed like nn.Linear (instead of nn.Conv2d):
        w = self.x_embedder.proj.weight.data
        nn.init.xavier_uniform_(w.view([w.shape[0], -1]))
        nn.init.constant_(self.x_embedder.proj.bias, 0)

        # Initialize label embedding table:
        nn.init.normal_(self.y_embedder.embedding_table.weight, std=0.02)

        # Initialize timestep embedding MLP:
        nn.init.normal_(self.t_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.t_embedder.mlp[2].weight, std=0.02)

        # Zero-out adaLN modulation layers in DiT blocks:
        for block in self.blocks:
            nn.init.constant_(block.adaLN_modulation[-1].weight, 0)
            nn.init.constant_(block.adaLN_modulation[-1].bias, 0)

        # Zero-out output layers:
        nn.init.constant_(self.final_layer.adaLN_modulation[-1].weight, 0)
        nn.init.constant_(self.final_layer.adaLN_modulation[-1].bias, 0)
        nn.init.constant_(self.final_layer.linear.weight, 0)
        nn.init.constant_(self.final_layer.linear.bias, 0)

    def unpatchify(self, x):
        """
        x: (N, T, patch_size**2 * C)
        imgs: (N, H, W, C)
        """
        c = self.out_channels
        p = self.x_embedder.patch_size[0]
        h = w = int(x.shape[1] ** 0.5)
        assert h * w == x.shape[1]

        x = x.reshape(shape=(x.shape[0], h, w, p, p, c))
        x = torch.einsum('nhwpqc->nchpwq', x)
        imgs = x.reshape(shape=(x.shape[0], c, h * p, h * p))
        return imgs

    def forward(self, x, t, y):
        """
        Forward pass of DiT.
        x: (N, C, H, W) tensor of spatial inputs (images)
        """
        x = self.x_embedder(x) + self.pos_embed  # (N, T, D)
        t = self.t_embedder(t)  # (N, D)
        y = self.y_embedder(y, self.training)  # (N, D)
        c = t + y  # (N, D)

        for block in self.blocks:
            x = block(x, c)  # Pass the conditioning vector directly.

        x = self.final_layer(x, c)  # (N, T, patch_size ** 2 * out_channels)
        return x

    def forward_with_cfg(self, x, t, y, cfg_scale):
        """
        Forward pass of DiT, but also batches the unconditional forward pass for classifier-free guidance.
        """
        # https://github.com/openai/glide-text2im/blob/main/notebooks/text2im.ipynb
        half = x[: len(x) // 2]
        combined = torch.cat([half, half], dim=0)
        model_out = self.forward(combined, t, y)
        # For exact reproducibility reasons, we apply classifier-free guidance on only
        # three channels by default. The standard approach to cfg applies it to all channels.
        # This can be done by uncommenting the following line and commenting-out the line following that.
        # eps, rest = model_out[:, :self.in_channels], model_out[:, self.in_channels:]
        eps, rest = model_out[:, :3], model_out[:, 3:]
        cond_eps, uncond_eps = torch.split(eps, len(eps) // 2, dim=0)
        half_eps = uncond_eps + cfg_scale * (cond_eps - uncond_eps)
        eps = torch.cat([half_eps, half_eps], dim=0)
        return torch.cat([eps, rest], dim=1)


#################################################################################
#                   Sine/Cosine Positional Embedding Functions                  #
#################################################################################
# https://github.com/facebookresearch/mae/blob/main/util/pos_embed.py

def get_2d_sincos_pos_embed(embed_dim, grid_size, cls_token=False, extra_tokens=0):
    """
    grid_size: int of the grid height and width
    return:
    pos_embed: [grid_size*grid_size, embed_dim] or [1+grid_size*grid_size, embed_dim] (w/ or w/o cls_token)
    """
    grid_h = np.arange(grid_size, dtype=np.float32)
    grid_w = np.arange(grid_size, dtype=np.float32)
    grid = np.meshgrid(grid_w, grid_h)  # here w goes first
    grid = np.stack(grid, axis=0)

    grid = grid.reshape([2, 1, grid_size, grid_size])
    pos_embed = get_2d_sincos_pos_embed_from_grid(embed_dim, grid)
    if cls_token and extra_tokens > 0:
        pos_embed = np.concatenate([np.zeros([extra_tokens, embed_dim]), pos_embed], axis=0)
    return pos_embed


def get_2d_sincos_pos_embed_from_grid(embed_dim, grid):
    assert embed_dim % 2 == 0

    # use half of dimensions to encode grid_h
    emb_h = get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[0])  # (H*W, D/2)
    emb_w = get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[1])  # (H*W, D/2)

    emb = np.concatenate([emb_h, emb_w], axis=1) # (H*W, D)
    return emb


def get_1d_sincos_pos_embed_from_grid(embed_dim, pos):
    """
    embed_dim: output dimension for each position
    pos: a list of positions to be encoded: size (M,)
    out: (M, D)
    """
    assert embed_dim % 2 == 0
    omega = np.arange(embed_dim // 2, dtype=np.float64)
    omega /= embed_dim / 2.
    omega = 1. / 10000**omega  # (D/2,)

    pos = pos.reshape(-1)  # (M,)
    out = np.einsum('m,d->md', pos, omega)  # (M, D/2), outer product

    emb_sin = np.sin(out) # (M, D/2)
    emb_cos = np.cos(out) # (M, D/2)

    emb = np.concatenate([emb_sin, emb_cos], axis=1)  # (M, D)
    return emb


#################################################################################
#                                   DiT Configs                                  #
#################################################################################

def DiT_XL_2(**kwargs):
    return DiT(depth=28, hidden_size=1152, patch_size=2, num_heads=16, **kwargs)

def DiT_XL_4(**kwargs):
    return DiT(depth=28, hidden_size=1152, patch_size=4, num_heads=16, **kwargs)

def DiT_XL_8(**kwargs):
    return DiT(depth=28, hidden_size=1152, patch_size=8, num_heads=16, **kwargs)

def DiT_L_2(**kwargs):
    return DiT(depth=24, hidden_size=1024, patch_size=2, num_heads=16, **kwargs)

def DiT_L_4(**kwargs):
    return DiT(depth=24, hidden_size=1024, patch_size=4, num_heads=16, **kwargs)

def DiT_L_8(**kwargs):
    return DiT(depth=24, hidden_size=1024, patch_size=8, num_heads=16, **kwargs)

def DiT_B_2(**kwargs):
    return DiT(depth=12, hidden_size=768, patch_size=2, num_heads=12, **kwargs)

def DiT_B_4(**kwargs):
    return DiT(depth=12, hidden_size=768, patch_size=4, num_heads=12, **kwargs)

def DiT_B_8(**kwargs):
    return DiT(depth=12, hidden_size=768, patch_size=8, num_heads=12, **kwargs)

def DiT_S_2(**kwargs):
    return DiT(depth=12, hidden_size=384, patch_size=2, num_heads=6, **kwargs)

def DiT_S_4(**kwargs):
    return DiT(depth=12, hidden_size=384, patch_size=4, num_heads=6, **kwargs)

def DiT_S_8(**kwargs):
    return DiT(depth=12, hidden_size=384, patch_size=8, num_heads=6, **kwargs)


DiT_models = {
    'DiT-XL/2': DiT_XL_2,  'DiT-XL/4': DiT_XL_4,  'DiT-XL/8': DiT_XL_8,
    'DiT-L/2':  DiT_L_2,   'DiT-L/4':  DiT_L_4,   'DiT-L/8':  DiT_L_8,
    'DiT-B/2':  DiT_B_2,   'DiT-B/4':  DiT_B_4,   'DiT-B/8':  DiT_B_8,
    'DiT-S/2':  DiT_S_2,   'DiT-S/4':  DiT_S_4,   'DiT-S/8':  DiT_S_8,
}
